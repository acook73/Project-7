#!/bin/sh
echo -ne '\033c\033]0;Project 7\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/Lila's_Quest_Linux_exe.x86_64" "$@"
